<?php
include 'conexion.php';

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=asignacion.xls");
header("Pragma: no-cache");
header("Expires: 0");

echo "<table border='1'>";
echo "<tr>";
echo "<th>ID</th>";
echo "<th>Dia de semana</th>";
echo "<th>Fecha de inicio</th>";
echo "<th>Fecha de finalización</th>";
echo "<th>Numero de ficha</th>";
echo "<th>Programa</th>";
echo "<th>Ambiente</th>";
echo "<th>Nombre instructor</th>";
echo "<th>Apellido de instructor</th>";
echo "<th>Jornada</th>";

echo "</tr>";

// Consulta productos
$sql = "SELECT a.idasignacion, a.diasemana, a.fechaini, a.fechafin, f.nficha, p.nombreprograma, am.nombre AS nombre_ambiente, i.nombres AS nombre_instructor, i.apellidos AS apellido_instructor, j.nombrejornada FROM asignacion a
    INNER JOIN ficha f ON a.nficha = f.nficha
    INNER JOIN programa p ON f.idprograma = p.idprograma
    INNER JOIN ambiente am ON a.idambiente = am.idambiente
    INNER JOIN instructor i ON a.idinstructor = i.idinstructor
    INNER JOIN jornada j ON a.idjornada = j.idjornada";
$resultado = mysqli_query($conn, $sql);

// Imprimir resultados como filas
while ($row = mysqli_fetch_assoc($resultado)) {
    echo "<tr>";
    echo "<td>{$row['idasignacion']}</td>";
    echo "<td>{$row['diasemana']}</td>";
    echo "<td>{$row['fechaini']}</td>";
    echo "<td>{$row['fechafin']}</td>";
    echo "<td>{$row['nficha']}</td>";
    echo "<td>{$row['nombreprograma']}</td>";
    echo "<td>{$row['nombre_ambiente']}</td>";
    echo "<td>{$row['nombre_instructor']}</td>";
    echo "<td>{$row['apellido_instructor']}</td>";
    echo "<td>{$row['nombrejornada']}</td>";
    echo "</tr>";
}

echo "</table>";
