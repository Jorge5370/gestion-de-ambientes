<?php
include 'conexion.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['idambiente'])) {
    $idambiente = $_GET['idambiente'];
    $resultado = mysqli_query($conn, "SELECT idambiente, nombre, descripcion FROM ambiente WHERE idambiente = '$idambiente'");
    $listadeAmbientes = mysqli_fetch_assoc($resultado);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];

    if ($idambiente) {
        $sql = "UPDATE ambiente SET nombre = '$nombre', descripcion = '$descripcion' WHERE idambiente = '$idambiente'";
        if (mysqli_query($conn, $sql)) {
            header("Location: ambientes_listar.php");
            exit();
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar Ambiente</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

</head>

<body>

    <?php include 'header.php'; ?>

    <div class="container mt-5 pt-3">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h2 class="text-center text-primary mb-4">Modificar Ambiente</h2>

                <br>
                <a href="ambientes_listar.php" class="btn btn-secondary mb-4">🔙 Volver</a>


                <form method="post" class="bg-light p-4 rounded shadow-sm">
                    <div class="mb-3">
                        <label class="form-label">ID Ambiente</label>
                        <input type="text" class="form-control" value="<?= htmlspecialchars($listadeAmbientes['idambiente']) ?>" disabled>
                    </div>

                    <div class="mb-3">
                        <label for="nombre" class="form-label">Nombre</label>
                        <input type="text" name="nombre" id="nombre" class="form-control" value="<?= htmlspecialchars($listadeAmbientes['nombre']) ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="descripcion" class="form-label">Descripción</label>
                        <textarea name="descripcion" id="descripcion" class="form-control" rows="4" required><?= trim($listadeAmbientes['descripcion']) ?></textarea>
                    </div>

                    <div class="d-flex justify-content-between">
                        <input type="submit" value="💾 Actualizar" class="btn btn-success">
                        <a href="ambientes_listar.php" class="btn btn-danger">❌ Cancelar</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <br>
    <?php include 'footer.php';  ?>


    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>