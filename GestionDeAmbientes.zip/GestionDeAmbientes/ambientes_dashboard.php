<?php
include 'conexion.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

$sql = "SELECT * FROM ambiente";
$resultado = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Ambientes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</head>

<?php include 'header.php'; ?>

<body>
    <div class="container pt-5 mt-4">
        <h1 class="text-center mb-4">Ambientes</h1>
        <a href="index.php" class="btn btn-secondary mb-4">🔙 Volver</a>

        <div class="row">
            <?php while ($ambiente = mysqli_fetch_assoc($resultado)) { ?>
                <div class="col-md-4">
                    <div class="card mb-4 shadow">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($ambiente['nombre']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($ambiente['descripcion']) ?></p>
                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal<?= $ambiente['idambiente'] ?>">
                                Asignar
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Modal con iframe -->
                <div class="modal fade" id="modal<?= $ambiente['idambiente'] ?>" tabindex="-1" aria-labelledby="modalLabel<?= $ambiente['idambiente'] ?>" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="modalLabel<?= $ambiente['idambiente'] ?>">Asignar: <?= htmlspecialchars($ambiente['nombre']) ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                            </div>
                            <div class="modal-body p-0">
                                <iframe src="asignacion_modal.php?idambiente=<?= $ambiente['idambiente'] ?>" width="100%" height="500px" frameborder="0"></iframe>
                            </div>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php include 'footer.php'; ?>
</body>

</html>
