<?php

include 'conexion.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['nficha'])) {
    $nficha = $_GET['nficha'];
    

    $sql = "DELETE FROM ficha WHERE nficha = '$nficha'";
    if (mysqli_query($conn, $sql)) {
        header("Location: fichas_listar.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
} 

?>