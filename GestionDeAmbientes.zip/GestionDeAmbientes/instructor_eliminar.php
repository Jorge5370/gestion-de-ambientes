<?php

include 'conexion.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['idinstructor'])) {
    $idinstructor = $_GET['idinstructor'];
    

    $sql = "DELETE FROM instructor WHERE idinstructor = '$idinstructor'";
    if (mysqli_query($conn, $sql)) {
        header("Location: instructor_listar.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
} 

?>