<?php
include 'conexion.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

$fichas = mysqli_query($conn, "SELECT nficha FROM ficha");
$instructores = mysqli_query($conn, "SELECT idinstructor, CONCAT(nombres, ' ', apellidos) AS nombre FROM instructor");
$ambientes = mysqli_query($conn, "SELECT idambiente, nombre FROM ambiente");
$jornadas = mysqli_query($conn, "SELECT idjornada, nombrejornada FROM jornada");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $diasemana = $_POST['diasemana'];
    $fechaini = $_POST['fechaini'];
    $fechafin = $_POST['fechafin'];
    $nficha = $_POST['nficha'];
    $idinstructor = $_POST['idinstructor'];
    $idambiente = $_POST['idambiente'];
    $idjornada = $_POST['idjornada'];

    $sql = "INSERT INTO asignacion (diasemana, fechaini, fechafin, nficha, idinstructor, idambiente, idjornada)
            VALUES ('$diasemana', '$fechaini', '$fechafin', '$nficha', '$idinstructor', '$idambiente', '$idjornada')";

    if (mysqli_query($conn, $sql)) {
        header("Location: asignacion_listar.php");
        exit();
    } else {
        echo "Error al insertar: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Asignar Ambiente</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</head>

<body>

    <?php include 'header.php';  ?>

    <div class="container mt-5 pt-3">
        <h2 class="text-center mb-4">Asignar Ambiente</h2>
        <br>

        <a href="asignacion_listar.php" class="btn btn-secondary mb-4">🔙 Volver</a>


        <form method="post">

            <div class="row mb-3">
                <div class="col">
                    <label for="fechaini">Fecha inicio</label>
                    <input type="date" name="fechaini" class="form-control" required>
                </div>
                <div class="col">
                    <label for="fechafin">Fecha fin</label>
                    <input type="date" name="fechafin" class="form-control" required>
                </div>
            </div>

            <div class="row mb-3">
                <div class="col">
                    <label for="nficha">Ficha</label>
                    <select name="nficha" class="form-control" required>
                        <option value="">Seleccione</option>
                        <?php while ($row = mysqli_fetch_assoc($fichas)) { ?>
                            <option value="<?= $row['nficha'] ?>"><?= $row['nficha'] ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="col">
                    <label for="idinstructor">Instructor</label>
                    <select name="idinstructor" class="form-control" required>
                        <option value="">Seleccione</option>
                        <?php while ($row = mysqli_fetch_assoc($instructores)) { ?>
                            <option value="<?= $row['idinstructor'] ?>"><?= $row['nombre'] ?></option>
                        <?php } ?>
                    </select>
                </div>
            </div>

            <div class="row mb-3">
                <div class="col">
                    <label for="idambiente">Ambiente</label>
                    <select name="idambiente" class="form-control" required>
                        <option value="">Seleccione</option>
                        <?php while ($row = mysqli_fetch_assoc($ambientes)) { ?>
                            <option value="<?= $row['idambiente'] ?>"><?= $row['nombre'] ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="col">
                    <label for="idjornada">Jornada</label>
                    <select name="idjornada" class="form-control" required>
                        <option value="">Seleccione</option>
                        <?php while ($row = mysqli_fetch_assoc($jornadas)) { ?>
                            <option value="<?= $row['idjornada'] ?>"><?= $row['nombrejornada'] ?></option>
                        <?php } ?>
                    </select>
                </div>
            </div>

            <div class="col-6">
                <label for="diasemana">Día de la semana</label>
                <select name="diasemana" class="form-control" required>
                    <option value="">Seleccione un día</option>
                    <option value="Lunes">Lunes</option>
                    <option value="Martes">Martes</option>
                    <option value="Miércoles">Miércoles</option>
                    <option value="Jueves">Jueves</option>
                    <option value="Viernes">Viernes</option>
                    <option value="Sábado">Sábado</option>
                    <option value="Domingo">Domingo</option>
                </select>
            </div>
            <br>
            <button type="submit" class="btn btn-success">Guardar</button>
            <a href="asignacion_listar.php" class="btn btn-danger">Cancelar</a>

        </form>
    </div>

    <br>
    <?php include 'footer.php';  ?>

    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>