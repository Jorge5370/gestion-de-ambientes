<?php
include 'conexion.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nficha = $_POST['nficha'];
    $idprograma = $_POST['idprograma'];
    $nuevoPrograma = trim($_POST['nuevo_programa']);

    // Si el usuario escribió un nuevo programa
    if ($idprograma == "nuevo" && !empty($nuevoPrograma)) {
        // Insertar nuevo programa
        $insertPrograma = "INSERT INTO programa (nombreprograma) VALUES ('$nuevoPrograma')";
        mysqli_query($conn, $insertPrograma);
        $idprograma = mysqli_insert_id($conn); // Obtener el ID del nuevo programa
    }

    // Insertar ficha
    $sqlFicha = "INSERT INTO ficha (nficha, idprograma) VALUES ('$nficha', '$idprograma')";
    if (mysqli_query($conn, $sqlFicha)) {
        echo "<script>alert('Ficha y programa registrados correctamente'); window.location='fichas_listar.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

$programas = mysqli_query($conn, "SELECT idprograma, nombreprograma FROM programa");
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Registrar Ficha</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

    <script>
        function toggleNuevoPrograma(select) {
            const nuevoProgramaDiv = document.getElementById("nuevoProgramaDiv");
            nuevoProgramaDiv.style.display = (select.value === "nuevo") ? "block" : "none";
        }
    </script>
</head>

<body>
    <?php include 'header.php';  ?>

    <div class="container mt-5 pt-3">
        <h2 class="text-center">Registrar nueva ficha</h2>
        <a href="fichas_listar.php" class="btn btn-secondary">🔙 Volver</a>
        <br><br>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Número de ficha</label>
                <input type="number" class="form-control" name="nficha" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Programa</label>
                <select name="idprograma" class="form-select" onchange="toggleNuevoPrograma(this)" required>
                    <option value="">Seleccione un programa</option>
                    <?php while ($row = mysqli_fetch_assoc($programas)) { ?>
                        <option value="<?= $row['idprograma'] ?>"><?= $row['nombreprograma'] ?></option>
                    <?php } ?>
                    <option value="nuevo">🆕 Agregar nuevo programa</option>
                </select>
            </div>

            <div class="mb-3" id="nuevoProgramaDiv" style="display: none;">
                <label class="form-label">Nombre del nuevo programa</label>
                <input type="text" name="nuevo_programa" class="form-control">
            </div>

            <button type="submit" class="btn btn-primary">Guardar ficha</button>
        </form>
    </div>

    <br>

    <?php include 'footer.php'; ?>


    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>