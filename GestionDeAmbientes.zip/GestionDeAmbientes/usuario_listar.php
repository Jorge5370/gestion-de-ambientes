<?php
include 'conexion.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

$busqueda = "";
if (isset($_GET['buscar'])) {
    $busqueda = $_GET['buscar'];
    $resultado = mysqli_query($conn, "SELECT usuario, email, nombre FROM usuarios WHERE nombre LIKE '%$busqueda%' OR email LIKE '%$busqueda%' ");
} else {
    $resultado = mysqli_query($conn, "SELECT usuario, email, nombre FROM usuarios");
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Usuarios</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/v/bs5/dt-2.3.2/datatables.min.css" rel="stylesheet" integrity="sha384-nt2TuLL4RlRQ9x6VTFgp009QD7QLRCYX17dKj9bj51w2jtWUGFMVTveRXfdgrUdx" crossorigin="anonymous">
</head>

<body>

    <?php include 'header.php'; ?>

    <div class="container mt-5 pt-3 shadow p-4 rounded bg-light">
        <h2 class="text-center mb-4 text-primary">👥 Lista de Usuarios</h2>

        <form method="get">
            <div class="row mb-3">
                <div class="col-md-5">
                    <a href="index.php" class="btn btn-success me-2 mb-2"><i class="bi bi-house-door-fill"></i> Panel de control</a>
                    <a href="usuario_nuevo.php" class="btn btn-primary mb-2"><i class="bi bi-person-plus-fill"></i> Nuevo</a>
                </div>
                <!-- Descomenta esto si deseas activar la búsqueda -->
                <!--
                <div class="col-md-5">
                    <input type="text" name="buscar" class="form-control" placeholder="Buscar por nombre o email" value="<?= $busqueda ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-outline-success w-100">🔍 Buscar</button>
                </div>
                -->
            </div>
        </form>

        <table class="table table-striped table-hover table-bordered border-dark text-center align-middle" id="myTable">
            <thead class="table-dark">
                <tr>
                    <th>Usuario</th>
                    <th>Email</th>
                    <th>Nombre</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($resultado)) { ?>
                    <tr>
                        <td><?= $row['usuario'] ?></td>
                        <td><?= $row['email'] ?></td>
                        <td><?= $row['nombre'] ?></td>
                        <td>
                            <a class="btn btn-outline-primary btn-sm me-1" href="usuario_modificar.php?usuario=<?= $row['usuario'] ?>">
                                <i class="bi bi-pencil-square"></i> Editar
                            </a>
                            <a class="btn btn-outline-danger btn-sm" href="usuario_eliminar.php?usuario=<?= $row['usuario'] ?>" onclick="return confirm('¿Eliminar?')">
                                <i class="bi bi-trash"></i> Eliminar
                            </a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <br>

    <?php include 'footer.php'; ?>

    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/v/bs5/dt-2.3.2/datatables.min.js" integrity="sha384-rL0MBj9uZEDNQEfrmF51TAYo90+AinpwWp2+duU1VDW/RG7flzbPjbqEI3hlSRUv" crossorigin="anonymous"></script>

    <script>
        $(document).ready(function() {
            $('#myTable').DataTable({
                language: {
                    url: 'https://cdn.datatables.net/plug-ins/2.3.2/i18n/es-ES.json'
                }
            });
        });
    </script>

</body>

</html>
