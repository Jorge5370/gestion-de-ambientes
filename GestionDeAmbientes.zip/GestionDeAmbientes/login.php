<?php
session_start();
include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = $_POST['usuario'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM usuarios WHERE usuario = '$usuario'";
    $result = mysqli_query($conn, $sql);

    if ($row = mysqli_fetch_assoc($result)) {
        if (password_verify($password, $row['password'])) {
            $_SESSION['usuario'] = $row['usuario'];
            $_SESSION['nombre'] = $row['nombre'];
            header("Location: index.php");
            exit();
        }
    }
    $error = "Usuario o contraseña incorrectos.";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - SENA</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        :root {
            --sena-verde-oscuro: #0D4D2B;
            --sena-verde-claro: #5B8C3C;
            --sena-blanco: #FFFFFF;
            --sena-gris: #F5F5F5;
            --sena-texto: #333333;
            --sena-error: #D32F2F;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Roboto', sans-serif;
        }
        
        body {
            background-color: var(--sena-gris);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-image: url('https://www.sena.edu.co/es-co/PublishingImages/Patron%20SENA%20WEB.png');
            background-size: cover;
            background-position: center;
        }
        
        .login-container {
            display: flex;
            width: 900px;
            max-width: 90%;
            height: 500px;
            background-color: var(--sena-blanco);
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
        }
        
        .logo-section {
            flex: 1;
            background-color: var(--sena-verde-oscuro);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 40px;
            position: relative;
            overflow: hidden;
        }
        
        .logo-section::before {
            content: "";
            position: absolute;
            top: -50px;
            right: -50px;
            width: 200px;
            height: 200px;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
        }
        
        .logo-section::after {
            content: "";
            position: absolute;
            bottom: -80px;
            right: -30px;
            width: 200px;
            height: 200px;
            background-color: rgba(255, 255, 255, 0.05);
            border-radius: 50%;
        }
        
        .logo-section img {
            width: 200px;
            margin-bottom: 30px;
            z-index: 2;
        }
        
        .logo-section h2 {
            color: var(--sena-blanco);
            font-size: 24px;
            font-weight: 500;
            text-align: center;
            z-index: 2;
        }
        
        .login-section {
            flex: 1;
            padding: 60px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        
        .login-header {
            margin-bottom: 30px;
        }
        
        .login-header h1 {
            color: var(--sena-verde-oscuro);
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 10px;
        }
        
        .login-header p {
            color: var(--sena-texto);
            font-size: 14px;
        }
        
        .alert-error {
            background-color: rgba(211, 47, 47, 0.1);
            color: var(--sena-error);
            padding: 12px 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 14px;
            display: <?php echo isset($error) ? 'flex' : 'none'; ?>;
            align-items: center;
            gap: 10px;
        }
        
        .alert-error i {
            font-size: 18px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            color: var(--sena-verde-oscuro);
            font-size: 14px;
            font-weight: 500;
        }
        
        .input-group {
            position: relative;
        }
        
        .input-group i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--sena-verde-claro);
            font-size: 16px;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px 12px 45px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            transition: all 0.3s;
            background-color: var(--sena-gris);
            color: var(--sena-texto);
        }
        
        .form-control:focus {
            border-color: var(--sena-verde-claro);
            outline: none;
            box-shadow: 0 0 0 3px rgba(91, 140, 60, 0.2);
            background-color: var(--sena-blanco);
        }
        
        .btn-sena {
            width: 100%;
            padding: 14px;
            background-color: var(--sena-verde-oscuro);
            color: var(--sena-blanco);
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .btn-sena:hover {
            background-color: var(--sena-verde-claro);
        }
        
        .login-footer {
            margin-top: 20px;
            text-align: center;
            font-size: 13px;
            color: var(--sena-texto);
        }
        
        .login-footer a {
            color: var(--sena-verde-oscuro);
            text-decoration: none;
            font-weight: 500;
        }
        
        .login-footer a:hover {
            text-decoration: underline;
        }
        
        @media (max-width: 768px) {
            .login-container {
                flex-direction: column;
                height: auto;
            }
            
            .logo-section {
                padding: 30px;
            }
            
            .logo-section img {
                width: 150px;
                margin-bottom: 20px;
            }
            
            .login-section {
                padding: 40px 30px;
            }
        }
        
        @media (max-width: 480px) {
            .login-container {
                max-width: 95%;
            }
            
            .login-section {
                padding: 30px 20px;
            }
            
            .login-header h1 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="logo-section">
            <img src="logoSena.png" alt="Logo SENA">
            <h2>Servicio Nacional de Aprendizaje</h2>
        </div>
        
        <div class="login-section">
            <div class="login-header">
                <h1>Iniciar Sesión</h1>
                <p>Ingrese sus credenciales para acceder al sistema</p>
            </div>
            
            <?php if (isset($error)): ?>
                <div class="alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <span><?= $error ?></span>
                </div>
            <?php endif; ?>
            
            <form method="post">
                <div class="form-group">
                    <label for="usuario" class="form-label">Usuario</label>
                    <div class="input-group">
                        <i class="fas fa-user"></i>
                        <input type="text" class="form-control" id="usuario" name="usuario" placeholder="Ingrese su usuario" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="password" class="form-label">Contraseña</label>
                    <div class="input-group">
                        <i class="fas fa-lock"></i>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Ingrese su contraseña" required>
                    </div>
                </div>
                
                <button type="submit" class="btn-sena">
                    <i class="fas fa-sign-in-alt"></i>
                    Acceder al sistema
                </button>
            </form>
            

        </div>
    </div>
</body>
</html>