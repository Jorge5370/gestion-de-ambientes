<?php
// Configuración de la conexión a la base de datos
$host = "localhost";
$user = "root";
$password = ""; // Cambia según tu configuración
$dbname = "gestion_ambientes";

// Crear la conexión
$conn = mysqli_connect($host, $user, $password, $dbname);
if(!$conn){//si no conecta detenerse y mostrar el error
    die("Error al conectarse: ".mysqli_connect_error());
}
?>