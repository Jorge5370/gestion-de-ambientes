<?php

include 'conexion.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

$busqueda = "";
if (isset($_GET['buscar'])) {
    $busqueda = $_GET['buscar'];

    $resultado = mysqli_query($conn, "SELECT idinstructor , nombres, apellidos FROM instructor WHERE nombres LIKE '%$busqueda%' OR apellidos LIKE '%$busqueda%' ");
} else {
    $resultado = mysqli_query($conn, "SELECT idinstructor , nombres, apellidos FROM instructor");
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instructores</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <!--Copio el link de una de las versiones de datatables en estilo, boostrap 5-->

    <link href="https://cdn.datatables.net/v/bs5/dt-2.3.2/datatables.min.css" rel="stylesheet" integrity="sha384-nt2TuLL4RlRQ9x6VTFgp009QD7QLRCYX17dKj9bj51w2jtWUGFMVTveRXfdgrUdx" crossorigin="anonymous">


</head>

<body>
    <?php include 'header.php';  ?>

    <div class="container mt-5 pt-3">

        <h2 class="text-center">Lista de Instructores</h2>

        <br>


        <form method="get">

            <div class="row">
                <div class="col-5">
                    <a href="index.php" class="btn btn-success">🏠Panel de control</a>


                    <a href="instructor_nuevo.php" class="btn btn-primary">🆕Nuevo</a>
                    <br>
                    <br>
                </div>
                <!---
                <div class="col-5">
                    <input type="text" name="buscar" class="form-control " placeholder="Buscar" value="<?= $busqueda ?>"> <br>
                </div>
                <div class="col-2">
                    <button type="submit" class="btn btn-success">Buscar</button>

                </div>
                 -->
            </div>

        </form>

        <br>

        <table class="table table-bordered border-dark text-center table-hover" id="myTable">
            <thead class="table-dark text-center">
                <tr>
                    <th>idinstructor</th>
                    <th>Nombres</th>
                    <th>Apellidos</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <?php while ($row = mysqli_fetch_assoc($resultado)) { ?>

                <tr>
                    <td class="col-3"><?= $row['idinstructor'] ?></td>
                    <td class="col-3"><?= $row['nombres'] ?></td>
                    <td class="col-3"><?= $row['apellidos'] ?></td>
                    <td class="col-3">
                        <a class="btn btn-info" href="instructor_modificar.php?idinstructor=<?= $row['idinstructor'] ?>">✏️Editar</a>
                        <a class="btn btn-danger" href="instructor_eliminar.php?idinstructor=<?= $row['idinstructor'] ?>" onclick="return confirm('¿Eliminar?')">🗑️ Eliminar </a>
                    </td>

                </tr>
            <?php } ?>
        </table>
    </div>
    

    <br>

    <?php include 'footer.php';  ?>


    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>




    <!--Copio el link de una de las versiones de jquery CDN-->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

    <!--Copio el link de una de las versiones de datatables en estilo, boostrap 5-->
    <script src="https://cdn.datatables.net/v/bs5/dt-2.3.2/datatables.min.js" integrity="sha384-rL0MBj9uZEDNQEfrmF51TAYo90+AinpwWp2+duU1VDW/RG7flzbPjbqEI3hlSRUv" crossorigin="anonymous"></script>

    <script>
        // let table = new DataTable('#myTable'); o usas este o el de abajo

        $(document).ready(function() {
            $('#myTable').DataTable({
                language: {
                    url: 'https://cdn.datatables.net/plug-ins/2.3.2/i18n/es-ES.json' // Asegúrate de tener este archivo o usar un CDN
                }
            });
        });
    </script>


</body>

</html>