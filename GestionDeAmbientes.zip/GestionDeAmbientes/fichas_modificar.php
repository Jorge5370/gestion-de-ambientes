<?php
include 'conexion.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['nficha'])) {
    $nficha = $_GET['nficha'];
    $resultado = mysqli_query($conn, "SELECT ficha.*, programa.nombreprograma 
        FROM ficha 
        INNER JOIN programa ON ficha.idprograma = programa.idprograma 
        WHERE nficha = '$nficha'
    ");
    $datosFicha = mysqli_fetch_assoc($resultado);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nficha = $_POST['nficha'];
    $nuevo_nficha = trim($_POST['nuevo_nficha']);
    $nombre_programa = trim($_POST['nombre_programa']);

    if (!empty($nuevo_nficha) && !empty($nombre_programa)) {
        // Verificar si el programa ya existe
        $check = mysqli_query($conn, "SELECT idprograma FROM programa WHERE nombreprograma = '$nombre_programa'");
        if (mysqli_num_rows($check) > 0) {
            $row = mysqli_fetch_assoc($check);
            $idprograma = $row['idprograma'];
        } else {
            // Insertar nuevo programa
            mysqli_query($conn, "INSERT INTO programa (nombreprograma) VALUES ('$nombre_programa')");
            $idprograma = mysqli_insert_id($conn);
        }

        // Actualizar la ficha
        $sql = "UPDATE ficha SET nficha = '$nuevo_nficha', idprograma = '$idprograma' WHERE nficha = '$nficha'";
        if (mysqli_query($conn, $sql)) {
            header("Location: fichas_listar.php");
            exit();
        } else {
            echo "Error al actualizar la ficha: " . mysqli_error($conn);
        }
    } else {
        echo "<script>alert('Por favor, complete todos los campos.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Editar Ficha</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

</head>

<body>
    <?php include 'header.php';  ?>

    <div class="container mt-5 pt-5">
        <h2 class="text-center">Editar Ficha</h2>
        <a href="fichas_listar.php" class="btn btn-secondary mb-4">🔙 Volver</a>

        <form method="POST">
            <input type="hidden" name="nficha" value="<?= $datosFicha['nficha'] ?>">

            <div class="mb-3">
                <label class="form-label">Número de ficha</label>
                <input type="number" class="form-control" name="nuevo_nficha" value="<?= $datosFicha['nficha'] ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Nombre del programa</label>
                <input type="text" name="nombre_programa" class="form-control" value="<?= $datosFicha['nombreprograma'] ?>" required>
            </div>

            <button type="submit" class="btn btn-success">Actualizar ficha</button>
            <a href="fichas_listar.php" class="btn btn-danger">Cancelar</a>
        </form>
    </div>

    <br>

    <?php include 'footer.php'; ?>


    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>