<?php
include 'conexion.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

$asignacion = null;
$error = "";

if (isset($_GET['idasignacion'])) {
    $idasignacion = mysqli_real_escape_string($conn, $_GET['idasignacion']);
    $resultado = mysqli_query($conn, "SELECT * FROM asignacion WHERE idasignacion = '$idasignacion'");
    if ($resultado && mysqli_num_rows($resultado) > 0) {
        $asignacion = mysqli_fetch_assoc($resultado);
    } else {
        $error = "Asignación no encontrada.";
    }
}

$fichas = mysqli_query($conn, "SELECT nficha FROM ficha");
$instructores = mysqli_query($conn, "SELECT idinstructor, CONCAT(nombres, ' ', apellidos) AS nombre FROM instructor");
$ambientes = mysqli_query($conn, "SELECT idambiente, nombre FROM ambiente");
$jornadas = mysqli_query($conn, "SELECT idjornada, nombrejornada FROM jornada");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $idasignacion = mysqli_real_escape_string($conn, $_POST['idasignacion']);
    $diasemana = mysqli_real_escape_string($conn, $_POST['diasemana']);
    $fechaini = mysqli_real_escape_string($conn, $_POST['fechaini']);
    $fechafin = mysqli_real_escape_string($conn, $_POST['fechafin']);
    $nficha = mysqli_real_escape_string($conn, $_POST['nficha']);
    $idinstructor = mysqli_real_escape_string($conn, $_POST['idinstructor']);
    $idambiente = mysqli_real_escape_string($conn, $_POST['idambiente']);
    $idjornada = mysqli_real_escape_string($conn, $_POST['idjornada']);

    $sql = "UPDATE asignacion SET diasemana = '$diasemana', fechaini = '$fechaini', fechafin = '$fechafin',
            nficha = '$nficha', idinstructor = '$idinstructor', idambiente = '$idambiente', idjornada = '$idjornada'
            WHERE idasignacion = '$idasignacion'";
    if (mysqli_query($conn, $sql)) {
        header("Location: asignacion_listar.php");
        exit();
    } else {
        $error = "Error al actualizar: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Modificar Asignación</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

</head>

<body>
    <?php include 'header.php'; ?>
    <div class="container mt-5 pt-3">
        <h2 class="text-center">Modificar Asignación</h2>
        <br>

        <a href="asignacion_listar.php" class="btn btn-secondary mb-4">🔙 Volver</a>

        <?php if ($error) { ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php } elseif ($asignacion) { ?>
            <form method="post">
                <input type="hidden" name="idasignacion" value="<?= $asignacion['idasignacion'] ?>">

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label>Día de la semana</label>
                        <select name="diasemana" class="form-control" required>
                            <?php
                            $dias = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"];
                            foreach ($dias as $dia) {
                                $selected = ($asignacion['diasemana'] == $dia) ? 'selected' : '';
                                echo "<option value='$dia' $selected>$dia</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label>Fecha Inicio</label>
                        <input type="date" name="fechaini" class="form-control" value="<?= $asignacion['fechaini'] ?>" required>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label>Fecha Fin</label>
                        <input type="date" name="fechafin" class="form-control" value="<?= $asignacion['fechafin'] ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label>Ficha</label>
                        <select name="nficha" class="form-control" required>
                            <?php while ($f = mysqli_fetch_assoc($fichas)) { ?>
                                <option value="<?= $f['nficha'] ?>" <?= $f['nficha'] == $asignacion['nficha'] ? 'selected' : '' ?>>
                                    <?= $f['nficha'] ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label>Instructor</label>
                        <select name="idinstructor" class="form-control" required>
                            <?php while ($i = mysqli_fetch_assoc($instructores)) { ?>
                                <option value="<?= $i['idinstructor'] ?>" <?= $i['idinstructor'] == $asignacion['idinstructor'] ? 'selected' : '' ?>>
                                    <?= $i['nombre'] ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label>Ambiente</label>
                        <select name="idambiente" class="form-control" required>
                            <?php while ($a = mysqli_fetch_assoc($ambientes)) { ?>
                                <option value="<?= $a['idambiente'] ?>" <?= $a['idambiente'] == $asignacion['idambiente'] ? 'selected' : '' ?>>
                                    <?= $a['nombre'] ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                </div>

                <div class="row mb-4">
                    <div class="col-md-6">
                        <label>Jornada</label>
                        <select name="idjornada" class="form-control" required>
                            <?php while ($j = mysqli_fetch_assoc($jornadas)) { ?>
                                <option value="<?= $j['idjornada'] ?>" <?= $j['idjornada'] == $asignacion['idjornada'] ? 'selected' : '' ?>>
                                    <?= $j['nombrejornada'] ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                </div>

                <button type="submit" class="btn btn-success">Actualizar</button>
                <a href="asignacion_listar.php" class="btn btn-danger">Cancelar</a>
            </form>

        <?php } ?>
    </div>

    <br>

    <?php include 'footer.php'; ?>

    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>