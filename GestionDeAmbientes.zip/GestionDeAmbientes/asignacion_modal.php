<?php
include 'conexion.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

$idambiente = $_GET['idambiente'] ?? null;

if (!$idambiente) {
    echo "<div class='alert alert-danger'>No se ha recibido el ambiente.</div>";
    exit;
}

$fichas = mysqli_query($conn, "SELECT nficha FROM ficha");
$instructores = mysqli_query($conn, "SELECT idinstructor, CONCAT(nombres, ' ', apellidos) AS nombre FROM instructor");
$jornadas = mysqli_query($conn, "SELECT idjornada, nombrejornada FROM jornada");

// Obtener asignaciones futuras del ambiente
$asignacionesFuturas = mysqli_query($conn, "
    SELECT a.fechaini, a.fechafin, j.nombrejornada, CONCAT(i.nombres, ' ', i.apellidos) AS instructor
    FROM asignacion a
    JOIN instructor i ON a.idinstructor = i.idinstructor
    JOIN jornada j ON a.idjornada = j.idjornada
    WHERE a.idambiente = '$idambiente'
      AND a.fechafin >= CURDATE()
    ORDER BY a.fechaini ASC
");

// Procesar formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fechaini = $_POST['fechaini'];
    $fechafin = $_POST['fechafin'];
    $nficha = $_POST['nficha'];
    $idinstructor = $_POST['idinstructor'];
    $idambiente = $_POST['idambiente'];
    $idjornada = $_POST['idjornada'];
    $diasemana = $_POST['diasemana'];

    $inicio = new DateTime($fechaini);
    $fin = new DateTime($fechafin);
    $fin->modify('+1 day');

    $rangoFechas = new DatePeriod($inicio, new DateInterval('P1D'), $fin);

    foreach ($rangoFechas as $fecha) {
        $dia = $fecha->format('Y-m-d');

        $query = mysqli_query($conn, "
            SELECT a.*, 
                   CONCAT(i.nombres, ' ', i.apellidos) AS instructor,
                   j.nombrejornada
            FROM asignacion a
            JOIN instructor i ON a.idinstructor = i.idinstructor
            JOIN jornada j ON a.idjornada = j.idjornada
            WHERE a.idambiente = '$idambiente'
              AND a.idjornada = '$idjornada'
              AND '$dia' BETWEEN a.fechaini AND a.fechafin
        ");

        if (mysqli_num_rows($query) > 0) {
            $ocupado = mysqli_fetch_assoc($query);
            echo "<script>
                alert('\u274C Conflicto: el ambiente ya est\u00e1 asignado el $dia a {$ocupado['instructor']} en la jornada {$ocupado['nombrejornada']} (del {$ocupado['fechaini']} al {$ocupado['fechafin']})');
                history.back();
            </script>";
            exit;
        }
    }

    $sql = "INSERT INTO asignacion (diasemana, fechaini, fechafin, nficha, idinstructor, idambiente, idjornada)
            VALUES ('$diasemana', '$fechaini', '$fechafin', '$nficha', '$idinstructor', '$idambiente', '$idjornada')";

    if (mysqli_query($conn, $sql)) {
        echo "<script>
            alert('\u2705 Asignaci\u00f3n registrada con \u00e9xito.');
            window.top.location.href = 'ambientes_dashboard.php';
        </script>";
        exit;
    } else {
        echo "<div class='alert alert-danger'>Error al insertar: " . mysqli_error($conn) . "</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Asignar Ambiente</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
</head>

<body>

    <div class="container mt-3 pt-3">
        <div class="accordion mb-4" id="asignacionesAccordion">
            <div class="accordion-item">
                <h2 class="accordion-header" id="headingOne">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseAsignaciones" aria-expanded="false" aria-controls="collapseAsignaciones">
                        Ver asignaciones futuras del ambiente
                    </button>
                </h2>
                <div id="collapseAsignaciones" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#asignacionesAccordion">
                    <div class="accordion-body">
                        <?php if (mysqli_num_rows($asignacionesFuturas) > 0): ?>
                            <ul class="list-group">
                                <?php while ($row = mysqli_fetch_assoc($asignacionesFuturas)): ?>
                                    <li class="list-group-item">
                                        Del <strong><?= $row['fechaini'] ?></strong> al <strong><?= $row['fechafin'] ?></strong> |
                                        <strong><?= $row['nombrejornada'] ?></strong> con <em><?= $row['instructor'] ?></em>
                                    </li>
                                <?php endwhile; ?>
                            </ul>
                        <?php else: ?>
                            <p class="text-muted">No hay asignaciones futuras.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <form method="post" onsubmit="return validarFechas();">
            <input type="hidden" name="idambiente" value="<?= htmlspecialchars($idambiente) ?>">

            <div class="row mb-3">
                <div class="col">
                    <label for="fechaini">Fecha inicio</label>
                    <input type="date" name="fechaini" id="fechaini" class="form-control" required>
                </div>
                <div class="col">
                    <label for="fechafin">Fecha fin</label>
                    <input type="date" name="fechafin" id="fechafin" class="form-control" required>
                </div>
            </div>

            <div class="row mb-3">
                <div class="col">
                    <label for="nficha">Ficha</label>
                    <select name="nficha" class="form-control" required>
                        <option value="">Seleccione</option>
                        <?php while ($row = mysqli_fetch_assoc($fichas)) { ?>
                            <option value="<?= $row['nficha'] ?>"><?= $row['nficha'] ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="col">
                    <label for="idinstructor">Instructor</label>
                    <select name="idinstructor" class="form-control" required>
                        <option value="">Seleccione</option>
                        <?php while ($row = mysqli_fetch_assoc($instructores)) { ?>
                            <option value="<?= $row['idinstructor'] ?>"><?= $row['nombre'] ?></option>
                        <?php } ?>
                    </select>
                </div>
            </div>

            <div class="row mb-3">
                <div class="col">
                    <label for="idjornada">Jornada</label>
                    <select name="idjornada" class="form-control" required>
                        <option value="">Seleccione</option>
                        <?php while ($row = mysqli_fetch_assoc($jornadas)) { ?>
                            <option value="<?= $row['idjornada'] ?>"><?= $row['nombrejornada'] ?></option>
                        <?php } ?>
                    </select>
                </div>
                <div class="col">
                    <label for="diasemana">Día de la semana</label>
                    <input type="text" class="form-control" id="diasemana_mostrar" readonly>
                    <input type="hidden" name="diasemana" id="diasemana" required>
                </div>
            </div>

            <div class="text-end">
                <button type="submit" class="btn btn-success">Guardar</button>
            </div>

        </form>
    </div>

    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('fechaini').addEventListener('change', function() {
            const partes = this.value.split('-'); // [YYYY, MM, DD]
            const fecha = new Date(partes[0], partes[1] - 1, partes[2]);
            const dias = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
            const nombreDia = !isNaN(fecha) ? dias[fecha.getDay()] : '';
            document.getElementById('diasemana_mostrar').value = nombreDia;
            document.getElementById('diasemana').value = nombreDia;
        });

        function validarFechas() {
            const ini = document.getElementById('fechaini').value;
            const fin = document.getElementById('fechafin').value;
            if (ini && fin && ini > fin) {
                alert('❌ La fecha fin no puede ser menor que la fecha inicio.');
                return false;
            }
            return true;
        }
    </script>

</body>

</html>