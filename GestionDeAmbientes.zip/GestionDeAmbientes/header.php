<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>

<body>
  <nav class="navbar navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
      <a class="navbar-brand">Menú de Inicio</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasDarkNavbar" aria-controls="offcanvasDarkNavbar" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="offcanvas offcanvas-end text-bg-dark" tabindex="-1" id="offcanvasDarkNavbar" aria-labelledby="offcanvasDarkNavbarLabel">
        <div class="offcanvas-header">
          <h5 class="offcanvas-title" id="offcanvasDarkNavbarLabel">Opciones</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
          <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Menú</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="ambientes_dashboard.php">Asignaciones de ambientes</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="ambientes_listar.php">Ambientes</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="asignacion_listar.php"> Historial de Asignaciones</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="fichas_listar.php">Fichas y programas</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="instructor_listar.php">Instructor</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="usuario_listar.php">Usuarios</a>
            </li>
            <li>
              <a href="logout.php" class="btn btn-danger">Cerrar sesión</a>
            </li>
        </div>
      </div>
    </div>
  </nav>

</body>

</html>