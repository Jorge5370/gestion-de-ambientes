<?php

include 'conexion.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Gestión de Ambientes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        .card-icon {
            font-size: 2.5rem;
            color: #0d6efd;
        }

        .card-title {
            font-size: 1.4rem;
            font-weight: 600;
        }

        .card-link {
            text-decoration: none;
            color: #0d6efd;
            font-weight: 500;
        }

        .card-link:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-dark bg-dark">
        <div class="container-fluid d-flex justify-content-between">
            <span class="navbar-brand mb-0 h1">Menú de Inicio</span>
            <a href="logout.php" class="btn btn-danger">Cerrar sesión</a>
        </div>
    </nav>

    <div class="container py-5">
        <div class="row g-4">

            <div class="col-md-4">
                <div class="card shadow-sm h-100">
                    <div class="card-body text-center">
                        <div class="card-icon mb-3"><i class="bi bi-building"></i></div>
                        <h5 class="card-title">Ambientes</h5>
                        <p class="card-text">Aquí están todos los ambientes existentes.</p>
                        <a href="ambientes_listar.php" class="card-link">Ver Ambientes →</a>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card shadow-sm h-100">
                    <div class="card-body text-center">
                        <div class="card-icon mb-3"><i class="bi bi-journal-check"></i></div>
                        <h5 class="card-title">Asignaciones</h5>
                        <p class="card-text">Podemos ver el historial de las asignaciones a cada ambiente.</p>
                        <a href="asignacion_listar.php" class="card-link">Ver asignaciones →</a>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card shadow-sm h-100">
                    <div class="card-body text-center">
                        <div class="card-icon mb-3"><i class="bi bi-journal-text"></i></div>
                        <h5 class="card-title">Fichas y Programas</h5>
                        <p class="card-text">Consulta los programas registrados y sus fichas asignadas.</p>
                        <a href="fichas_listar.php" class="card-link">Ver fichas y programas →</a>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card shadow-sm h-100">
                    <div class="card-body text-center">
                        <div class="card-icon mb-3"><i class="bi bi-person-workspace"></i></div>
                        <h5 class="card-title">Instructor</h5>
                        <p class="card-text">Consulta los instructores del SENA registrados en la plataforma.</p>
                        <a href="instructor_listar.php" class="card-link">Ver Instructores →</a>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card shadow-sm h-100">
                    <div class="card-body text-center">
                        <div class="card-icon mb-3"><i class="bi bi-person-lines-fill"></i></div>
                        <h5 class="card-title">Usuarios</h5>
                        <p class="card-text">Consulta los usuarios registrados en el sistema.</p>
                        <a href="usuario_listar.php" class="card-link">Ver Usuarios →</a>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card shadow-sm h-100">
                    <div class="card-body text-center">
                        <div class="card-icon mb-3"><i class="bi bi-diagram-3-fill"></i></div>
                        <h5 class="card-title">Asignacion de ambiente</h5>
                        <p class="card-text">Aqui encontraras los ambientes y podras gestionar su asignacion.</p>
                        <a href="ambientes_dashboard.php" class="card-link">Ver Asignacion de ambientes →</a>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <?php include 'footer.php'; ?>

</body>

</html>

