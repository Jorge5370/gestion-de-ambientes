<?php
include 'conexion.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

if (isset($_POST['idambiente'])) {
    $nombre = $_POST['nombre'];
    $idambiente = $_POST['idambiente'];
    $descripcion = $_POST['descripcion'];

    $sql = "INSERT INTO ambiente (idambiente, nombre, descripcion) VALUES ('$idambiente', '$nombre', '$descripcion')";
    if (mysqli_query($conn, $sql)) {
        header("Location: ambientes_listar.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Ambiente</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

</head>

<body>

    <?php include 'header.php'; ?>

    <div class="container mt-5 pt-3">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <h1 class="mb-4 text-primary text-center">Registrar Nuevo Ambiente</h1>
                <a href="ambientes_listar.php" class="btn btn-secondary">
                    🔙 Volver
                </a>
                <br>
                <br>

                <form method="post" class="bg-light p-4 rounded shadow-sm">

                    <div class="form-floating mb-3">
                        <input type="text" name="idambiente" id="idambiente" class="form-control" placeholder="101" required>
                        <label for="idambiente">ID Ambiente</label>
                    </div>

                    <div class="form-floating mb-3">
                        <input type="text" name="nombre" id="nombre" class="form-control" placeholder="Sala TIC" required>
                        <label for="nombre">Nombre</label>
                    </div>

                    <div class="form-floating mb-4">
                        <textarea name="descripcion" id="descripcion" class="form-control" placeholder="Da una breve descripción..." style="height: 150px;" required></textarea>
                        <label for="descripcion">Descripción</label>
                    </div>

                    <div class="d-flex justify-content-center gap-3">
                        <input type="submit" value="💾 Guardar" class="btn btn-success">
                        <a href="ambientes_listar.php" class="btn btn-danger">
                            ❌ Cancelar
                        </a>
                    </div>

                </form>
            </div>
        </div>
    </div>

    <br>
    <?php include 'footer.php';  ?>

    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>