<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">

</head>

<body>


    <footer class="bg-dark text-light pt-5">
        <div class="container px-5">
            <div class="row">
                <div class="col-6 col-lg-4">
                    <h3 class="fw-bold">Gestión de Ambientes</h3>
                    <p class="pt-2">Sistema para la administración eficiente de ambientes de formación del SENA.</p>
                </div>
                <div class="col">
                    <h4>Menú</h4>
                    <ul class="list-unstyled pt-2">
                        <li class="py-1">Inicio</li>
                        <li class="py-1">Ambientes</li>
                        <li class="py-1">Instructores</li>
                        <li class="py-1">Usuarios</li>
                    </ul>
                </div>
                <div class="col">
                    <h4>Soporte</h4>
                    <ul class="list-unstyled pt-2">
                        <p class="mb-2">Tel: 3126875363</p>
                        <p>Email: mejiasrafael83@gmail.com</p>
                    </ul>
                </div>
                <div class="col">
                    <h4>Recursos</h4>
                    <ul class="list-unstyled pt-2">
                        <li class="py-1">Fichas y Programas</li>
                        <li class="py-1">Historial de Asignaciones</li>
                        <li>Asignaciones de ambientes</li>
                    </ul>
                </div>
                <div class="col-6 col-lg-3 text-lg-end">
                    <h4>Redes Sociales</h4>
                    <div class="social-media pt-2">
                        <a href="https://www.facebook.com/rafael.mejia.58051" class="text-light fs-2 me-3"><i class="bi bi-facebook"></i></a>
                        <a href="https://www.instagram.com/rafael_mejia_salgado/" class="text-light fs-2 me-3"><i class="bi bi-instagram"></i></a>
                        <a href="https://www.linkedin.com/in/rafael-hernan-mej%C3%ADa-salgado-85a6182ba/" class="text-light fs-2"><i class="bi bi-linkedin"></i></a>
                    </div>
                </div>
            </div>
            <hr>
            <div class="d-sm-flex justify-content-between py-1">
                <p>2025 © Gestión de Ambientes - SENA. Todos los derechos reservados.</p>
                <p>
                    <a class="text-light text-decoration-none pe-4">Términos de uso</a>
                    <a class="text-light text-decoration-none">Políticas de privacidad</a>
                </p>
            </div>
        </div>
    </footer>


    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>


</body>

</html>