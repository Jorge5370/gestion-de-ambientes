<?php

include 'conexion.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['idambiente'])) {
    $idambiente = $_GET['idambiente'];
    

    $sql = "DELETE FROM ambiente WHERE idambiente = '$idambiente'";
    if (mysqli_query($conn, $sql)) {
        header("Location: ambientes_listar.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
} 

?>