<?php
require('fpdf186/fpdf.php');
include 'conexion.php';


// Consulta productos con nombre de fabricante
$sql = "SELECT a.idasignacion, a.diasemana, a.fechaini, a.fechafin, f.nficha, p.nombreprograma, am.nombre AS nombre_ambiente, i.nombres AS nombre_instructor, i.apellidos AS apellido_instructor, j.nombrejornada FROM asignacion a
    INNER JOIN ficha f ON a.nficha = f.nficha
    INNER JOIN programa p ON f.idprograma = p.idprograma
    INNER JOIN ambiente am ON a.idambiente = am.idambiente
    INNER JOIN instructor i ON a.idinstructor = i.idinstructor
    INNER JOIN jornada j ON a.idjornada = j.idjornada";
$result = mysqli_query($conn, $sql);

// Crear PDF
$pdf = new FPDF('L');
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, 'Listado de asignaciones', 0, 1, 'C');
$pdf->Ln(5);

// Cabecera
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(10, 10, 'Id', 1);
$pdf->Cell(30, 10, 'Dia de semana', 1);
$pdf->Cell(30, 10, 'Fecha de inicio', 1);
$pdf->Cell(30, 10, 'Fecha de fin', 1);
$pdf->Cell(30, 10, 'Ficha', 1);
$pdf->Cell(30, 10, 'Programa', 1);
$pdf->Cell(30, 10, 'Ambiente', 1);
$pdf->Cell(30, 10, 'Nombre instructor', 1);
$pdf->Cell(30, 10, 'Apellido instructor', 1);
$pdf->Cell(30, 10, 'Jornada', 1);

$pdf->Ln();

// Datos
$pdf->SetFont('Arial', '', 10);
while ($row = mysqli_fetch_assoc($result)) {
    $pdf->Cell(10, 10, $row['idasignacion'], 1);
    $pdf->Cell(30,10,mb_convert_encoding($row['diasemana'], 'ISO-8859-1', 'UTF-8'),1);
    $pdf->Cell(30, 10, $row['fechaini'], 1);
    $pdf->Cell(30, 10, $row['fechafin'], 1);
    $pdf->Cell(30, 10, $row['nficha'], 1);
    $pdf->Cell(30, 10, $row['nombreprograma'], 1);
    $pdf->Cell(30, 10, $row['nombre_ambiente'], 1);
    $pdf->Cell(30, 10, $row['nombre_instructor'], 1);
    $pdf->Cell(30, 10, $row['apellido_instructor'], 1);
    $pdf->Cell(30,10,mb_convert_encoding($row['nombrejornada'], 'ISO-8859-1', 'UTF-8'),1);
    $pdf->Ln();
}

$pdf->Output('I', 'asignaciones.pdf');
