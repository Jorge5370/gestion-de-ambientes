<?php
include 'conexion.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['usuario'])) {
    $usuario = $_GET['usuario'];
    $resultado = mysqli_query($conn, "SELECT * FROM usuarios WHERE usuario = '$usuario'");
    $listaUsuarios = mysqli_fetch_assoc($resultado);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $password = !empty($_POST['password']) ? password_hash($_POST['password'], PASSWORD_DEFAULT) : null; //Operador Ternario
    $usuario = mysqli_real_escape_string($conn, $_POST['usuario']);

    if ($password) {
        $sql = "UPDATE usuarios SET nombre = '$nombre', email = '$email', password = '$password' WHERE usuario = '$usuario'";
    } else {
        $sql = "UPDATE usuarios SET nombre = '$nombre', email = '$email' WHERE usuario = '$usuario'";
    }


    if (mysqli_query($conn, $sql)) {
        header("Location: usuario_listar.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar usuario</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">


</head>

<body>
    <?php include 'header.php';  ?>

    <div class="container mt-5 pt-3">
        <h2 class="text-center">Modificar Usuario</h2>
        <br>

        <a href="usuario_listar.php" class="btn btn-secondary mb-4">🔙 Volver</a>


        <form method="post">

            <input type="hidden" name="usuario" value="<?php echo $listaUsuarios['usuario']; ?>">


            <div class="row">
                <div class="col">
                    <p>Usuario</p>
                    <strong> <?= $listaUsuarios['usuario'] ?> </strong>
                </div>
            </div>
            <div class="row">
                <div class="col-6">
                    <p>Nombre</p>
                    <input type="text" class="form-control" name="nombre" value="<?php echo $listaUsuarios['nombre']; ?>" required>
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-6">
                    <p>Email</p>
                    <input type="email" class="form-control" name="email" value="<?php echo $listaUsuarios['email']; ?>" required>
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-6">
                    <p>Nueva Contraseña (Opcional)</p>
                    <input type="password" class="form-control" name="password">
                </div>
            </div>

            <br>

            <input type="submit" value="Actualizar" class="btn btn-success">

            <a href="usuario_listar.php" class="btn btn-danger">Cancelar</a>

        </form>
    </div>

    <br>


    <?php include 'footer.php'; ?>


    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>