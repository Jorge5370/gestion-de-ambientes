<?php
include 'conexion.php';

session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

if (isset($_POST['idinstructor'])) {
    $nombres = $_POST['nombres'];
    $idinstructor = $_POST['idinstructor'];
    $apellidos = $_POST['apellidos'];

    $sql = "INSERT INTO instructor (idinstructor, nombres, apellidos) VALUES ('$idinstructor', '$nombres', '$apellidos')";
    if (mysqli_query($conn, $sql)) {
        header("Location: instructor_listar.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuevo instructor</title>
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

</head>

<body>

    <?php include 'header.php';  ?>


    <div class="container mt-5 pt-3">

        <h2 class="text-center">Nuevo Instructor</h2>
        <br>

        <a href="instructor_listar.php" class="btn btn-secondary mb-4">🔙 Volver</a>


        <form method="post">

            <div class="row">
                <div class="col">
                    <p>Id_instructor</p>
                    <input type="text" class="form-control" placeholder="2846574" name="idinstructor" placeholder="Cedula" required>
                </div>
                <div class="col">
                    <p>Nombres</p>
                    <input type="text" class="form-control" placeholder="Tu nombre" name="nombres" required>
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-6">
                    <p>Apellidos</p>
                    <input type="text" class="form-control" placeholder="Tu apellido" name="apellidos" required>
                </div>
            </div>

            <br>

            <input type="submit" value="Guardar" class="btn btn-success">

            <a href="instructor_listar.php" class="btn btn-danger">Cancelar</a>

        </form>

    </div>

    <br>

    <?php include 'footer.php'; ?>


    <script src="bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>